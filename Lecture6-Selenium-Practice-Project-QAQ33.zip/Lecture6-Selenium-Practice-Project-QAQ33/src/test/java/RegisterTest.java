import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.security.Key;
import java.time.Duration;

public class RegisterTest {

    WebDriver driver;

    @BeforeMethod
    public void setup() {
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.get("https://auto.pragmatic.bg");

    }

   // @AfterMethod
    //public void tearDown() {

     //   driver.quit();
    //}

    @Test
    public void register() {
       WebElement myAccountLabel = driver.findElement(By.xpath("//i[@class='fa-solid fa-user']/ .."));
       myAccountLabel.click();

       WebElement registerLabel = driver.findElement(By.cssSelector(".dropdown-menu-right a"));
       registerLabel.click();

       WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(3));
       wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("input-firstname")));

       WebElement firstNameInputField = driver.findElement(By.id("input-firstname"));
       firstNameInputField.sendKeys("Buket");

        WebElement lastNameInputField = driver.findElement(By.id("input-lastname"));
        lastNameInputField.sendKeys("Ali");

        WebElement emailInputField = driver.findElement(By.id("input-email"));
        emailInputField.sendKeys("buketali@abv.bg");

        WebElement passwordInputField = driver.findElement(By.id("input-password"));
        passwordInputField.sendKeys("123456");

        WebElement checkbox = driver.findElement(By.xpath("//input[@name='agree']"));
        Actions actions = new Actions(driver);
        actions.moveToElement(checkbox).click().perform();

        WebElement submitButton = driver.findElement(By.className("btn-primary"));
        submitButton.click();

    }


}