import org.apache.commons.lang3.RandomStringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.time.Duration;

public class AddCustomerTest {

    WebDriver driver;

    @BeforeMethod
    public void setup() {
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.get("https://auto.pragmatic.bg/manage");
    }

    @AfterMethod
    public void tearDown() {
        driver.quit();
    }

    @Test
    public void addCustomerTest() {
        WebElement usernameInputField = driver.findElement(By.id("input-username"));
        usernameInputField.sendKeys("admin");

        WebElement passwordInputField = driver.findElement(By.id("input-password"));
        passwordInputField.sendKeys("parola123!");

        WebElement loginButton = driver.findElement(By.cssSelector("[type='submit']"));
        loginButton.click();

        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(5));

        wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector("li[id='menu-customer'] > a")));
        WebElement customersDropdown = driver.findElement(By.cssSelector("li[id='menu-customer'] > a"));
        customersDropdown.click();

        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//li[@id='menu-customer']//li[1]")));
        WebElement customers = driver.findElement(By.xpath("//li[@id='menu-customer']//li[1]"));
        customers.click();

        WebElement addCustomerButton = driver.findElement(By.xpath("//i[@class='fa-solid fa-plus']/ .."));
        addCustomerButton.click();

        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("input-firstname")));
        WebElement firstnameInputField = driver.findElement(By.id("input-firstname"));
        firstnameInputField.sendKeys("Petar");

        WebElement lastnameInputField = driver.findElement(By.id("input-lastname"));
        lastnameInputField.sendKeys("Petrov");

        String prefix = RandomStringUtils.randomAlphabetic(7);
        String suffix = RandomStringUtils.randomAlphabetic(5);
        String emailAddress = prefix + "@" + suffix + ".bg";

        WebElement emailInputField = driver.findElement(By.id("input-email"));
        emailInputField.sendKeys(emailAddress);

        String password = "1234";

        WebElement customerPasswordInputField = driver.findElement(By.id("input-password"));
        customerPasswordInputField.sendKeys(password);

        WebElement passwordConfirm = driver.findElement(By.id("input-confirm"));
        passwordConfirm.sendKeys(password);

        JavascriptExecutor javascriptExecutor = (JavascriptExecutor) driver;
        javascriptExecutor.executeScript("arguments[0].scrollIntoView(true);", driver.findElement(By.id("input-newsletter")));

        wait.until(d ->
                (Boolean)((JavascriptExecutor) d).executeScript(
                        "var rect = arguments[0].getBoundingClientRect();" +
                                "return (rect.top >= 0 && rect.bottom <= window.innerHeight);", driver.findElement(By.id("input-newsletter")))
        );

        WebElement newsletterCheckbox = driver.findElement(By.id("input-newsletter"));
        if(!newsletterCheckbox.isSelected()) {
            newsletterCheckbox.click();
        }

        WebElement saveButton = driver.findElement(By.xpath("//i[@class='fa-solid fa-floppy-disk']/ .."));
        saveButton.click();
    }

}
